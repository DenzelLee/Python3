#!usr/bin/python
# -*- coding: utf-8 -*-
import subprocess
import threading
import Tkinter as tk
import tkinter.messagebox
from duplicate_case import de_duplication
import datetime
#import tkMessageBox as messagebox
import os
from  tkinter.scrolledtext import ScrolledText #带滚动条的文本框
from Tkinter import END

path = os.path.dirname(os.path.dirname(__file__))
flask_path = path+'/flask_webdriver/flask_webdriver.py'
startup_path = path+ '/startup.py'

class WinDow():
    def __init__(self):
        self.window = tk.Tk()
        self.window.title('控制台')
        self.window.geometry('1250x850')
        self.var = tk.StringVar()
        self.var.set('url')#单选按钮设置默认值
    def loop(self):
        self.window.mainloop()
    def presentation_of_infomation(self):
        """
        各种控件的展示
        :return:
        """
        #label控件展示
        self.label = tk.Label(self.window,bg='yellow',width = '40',text='you have selected url')
        self.label.place(x=10,y=470)
        #创建三个rediobutten选项，其中variable = var,value='A' 的意思是，当我们鼠标选中了其中一个选项，把value的值放到变量var中
        r1 = tk.Radiobutton(self.window,text='url去重',variable= self.var,value='url',command=self.print_selection)
        r1.place(x=20,y=500)
        r2  = tk.Radiobutton(self.window,text='url+data去重',variable= self.var,value='url+data',command=self.print_selection)
        r2.place(x=130, y=500)
        r3 = tk.Radiobutton(self.window, text='url+data_key去重', variable=self.var, value='url+key',
                            command=self.print_selection)
        r3.place(x=280, y=500)
        #去重按钮
        btn_login = tk.Button(self.window,text = '点击去重',command=self.run_duplication)
        btn_login.place(x=210,y=550)
        #txt带滚动条的文本展示
        self.duplication_t = ScrolledText(self.window,height=12,width=80)#width 是字符的宽度heigh设置为12行
        self.duplication_t.place(x=10,y=600)
        #flask 文字展示
        self.flask_label = tk.Label(self.window,  text='后端服务flask',font=("华为行楷",20), width='30',height=3)
        self.flask_label.place(x=10, y=-20)
        # flask带滚动条的文本框展示
        self.flask_t = ScrolledText(self.window, height=25, width=80)  # width 是字符的宽度heigh设置为12行
        self.flask_t.place(x=10, y=100)
        # 启动flask按钮
        btn_run_flask = tk.Button(self.window, text='启动',fg='blue', command=self.run_flask_server)
        btn_run_flask.place(x=120, y=50)
        # 停止flask按钮
        btn_stop_flask = tk.Button(self.window, text='停止',fg='red', command=self.stop_flask_server)
        btn_stop_flask.place(x=180, y=50)
        # 清空flask日志按钮
        btn_clear_flask = tk.Button(self.window, text='清空日志',fg='red', command=self.clear_flask_log)
        btn_clear_flask.place(x=240, y=50)

        # 守护日志文字展示
        self.startup_label = tk.Label(self.window, text='守护服务', font=("华为行楷", 20), width='30', height=3)
        self.startup_label.place(x=730, y=-20)
        # 守护日志带滚动条的文本框展示
        self.startup_t = ScrolledText(self.window, height=25, width=80)  # width 是字符的宽度heigh设置为12行
        self.startup_t.place(x=630, y=100)
        # 启动startup按钮
        btn_run_startup = tk.Button(self.window, text='启动', fg='blue', command=self.run_startup_server)
        btn_run_startup.place(x=830, y=50)
        # 停止startup按钮
        btn_stop_flask = tk.Button(self.window, text='停止', fg='red', command=self.stop_startup_server)
        btn_stop_flask.place(x=890, y=50)
        # 清空startup日志按钮
        btn_clear_flask = tk.Button(self.window, text='清空日志', fg='red', command=self.clear_startup_log)
        btn_clear_flask.place(x=950, y=50)
    def modified(self,control):
        #自动刷新拉到底部显示
        control.see(END)
    def print_selection(self):
        """
        定义选项触发函数功能，动态显示单选按钮的结果在界面
        :return:
        """
        self.label.config(text= 'you have selected' + self.var.get())

    def run_duplication(self):
        self.message = de_duplication('requests_json.txt', self.var.get())
        #参数end表示以结尾开始依次展示，还有参数insert 表示以光标位置向后展示
        self.duplication_t.insert('end',str(datetime.datetime.now()).split('.')[0]+'   '+self.message+'\n')
        #tkinter.messagebox.showinfo('提示',self.message)
    def run_flask_server(self):
        pass
    def stop_flask_server(self):
        pass
    def clear_flask_log(self):
        pass
    def run_startup_server(self):
        pass
    def stop_startup_server(self):
        pass
    def clear_startup_log(self):
        pass

class Cmd(object,WinDow):
    """
    creationflags:windows下，传递CREATE_NEW_CONSOLE创建自己的控制台窗口
    stdin=subprocess.PIPE 创建管道
    stdout=subprocess.PIPE 把此管道的信息读取创建文件对象
    stderr=subprocess.PIPE 文件描述符
    """
    #多线程使用单利模式需要上锁，不然单利模式无效
    _instance_lock = threading.Lock()
    def __init__(self):
        WinDow.__init__(self)
        self.flask_pids = []
        self.startup_pids = []
    def __new__(cls, *args, **kwargs):
        if not hasattr(Cmd,"_instance"):
            with Cmd._instance_lock:
                if not hasattr(Cmd,"_instance"):
                    Cmd._instance = object.__new__(cls)
        return Cmd._instance


    def start_stf_flask(self):
        cmd = r"python {flask_path}".format(flask_path=flask_path)
        print('go to! The time is: %s'% datetime.datetime.now())
        self.stf_p_flask = subprocess.Popen(cmd,creationflags=subprocess.CREATE_NEW_CONSOLE,stdout=subprocess.PIPE,shell=True,
                                            stderr=subprocess.STDOUT
                                            )
        #此进程id 是shell进程
        pid = self.stf_p_flask.pid
        self.flask_pids.append(pid)
        while self.stf_p_flask.poll() is None:
            output_flask = self.stf_p_flask.stdout.readline()
            self.flask_t.insert('end',str(datetime.datetime.now()).split('.')[0]+'   '+output_flask+'\n')
            self.modified(self.flask_t)

    #重写run_flask_server方法
    def run_flask_server(self):
        self.t2=threading.Thread(target=self.start_stf_flask,args=())
        self.t2.start()
    def stop_flask_server(self):
        # 结束掉所有进程
        for pid in self.flask_pids:
            try:
                # 结束掉整个进程
                print(pid)
                # 此方法不能杀掉子进程
                # os.kill(pid,9)
                os.system("taskkill /t /f /pid %s" % pid)
                self.flask_pids.remove(pid)
            except:
                pass
        self.flask_t.insert('end',str(datetime.datetime.now()).split('.')[0]+'   '+"服务已停止"+'\n')
    def clear_flask_log(self):
        #清空text
        self.flask_t.delete(1.0,tk.END)

    def start_stf_startup(self):
        cmd = r"python {startup_path}".format(startup_path=startup_path)
        print('go to! The time is: %s'% datetime.datetime.now())
        self.stf_p_startup = subprocess.Popen(cmd,creationflags=subprocess.CREATE_NEW_CONSOLE,stdout=subprocess.PIPE,shell=True,
                                            stderr=subprocess.STDOUT
                                            )
        #此进程id 是shell进程
        pid = self.stf_p_startup.pid
        self.startup_pids.append(pid)
        while self.stf_p_startup.poll() is None:
            output_startup = self.stf_p_startup.stdout.readline()
            self.startup_t.insert('end',str(datetime.datetime.now()).split('.')[0]+'   '+output_startup+'\n')
            self.modified(self.startup_t)
    #重写run_flask_server方法
    def run_startup_server(self):
        self.t3=threading.Thread(target=self.start_stf_startup,args=())
        self.t3.start()
    def stop_startup_server(self):
        # 结束掉所有进程
        for pid in self.startup_pids:
            try:
                # 结束掉整个进程
                print(pid)
                # 此方法不能杀掉子进程
                # os.kill(pid,9)
                os.system("taskkill /t /f /pid %s" % pid)
                self.startup_pids.remove(pid)
            except:
                pass
        self.startup_t.insert('end',str(datetime.datetime.now()).split('.')[0]+'   '+"服务已停止"+'\n')
    def clear_startup_log(self):
        #清空text
        self.startup_t.delete(1.0,tk.END)
if __name__ == '__main__':
    A = Cmd()
    A.presentation_of_infomation()
    t1 = threading.Thread(target=A.loop,args=())
    t1.start()