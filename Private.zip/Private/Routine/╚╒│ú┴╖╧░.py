#!/usr/bin/env/python3
# -*- coding:utf-8 -*-
'''
Author:leo
Date&Time:2019/12/25 and 12:36
Project:Python3
FileName:日常练习
Description：...
'''
def len_str(test_str):
    """返回字符串长度"""
    str_len = len(test_str.encode("utf-8"))
    print(f'当前字符串长度为： {str_len}')
    return (str_len)

def binarySearch(arr, left, right, x):
    """算法：二分法"""
    while left <= right:
        mid = int(left + (right - left) / 2)  # 找到中间位置。求中点写成(left+right)/2更容易溢出，所以不建议这样写
        # 检查x是否出现在位置mid
        if arr[mid] == x:
            print('found %d 在索引位置%d 处' %(x, mid))
            return mid
            # 假如x更大，则不可能出现在左半部分
        elif arr[mid] < x:
            left = mid + 1  #搜索区间变为[mid+1,right]
            print('区间缩小为[%d,%d]' %(mid+1, right))
        elif x < arr[mid]:
            right = mid - 1  #搜索区间变为[left,mid-1]
            print('区间缩小为[%d,%d]' %(left, mid-1))
    return -1  # 0：返回假；1：返回真；-1：返回其他情况；

if __name__ =='__main__':
    len_str("abc")
    binarySearch([i for i in range(10)], 1, 10, 8)