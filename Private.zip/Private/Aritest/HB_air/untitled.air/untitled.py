# -*- encoding=utf8 -*-
__author__ = "leo"

from airtest.core.api import *

auto_setup(__file__)
to




