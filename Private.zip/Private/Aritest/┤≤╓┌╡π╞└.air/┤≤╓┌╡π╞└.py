# -*- encoding=utf8 -*-
__author__ = "Administrator"
auto_setup(__file__)

from airtest.core.api import *


from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from airtest_selenium.proxy import WebChrome
driver = WebChrome()
driver.implicitly_wait(20)

driver.get("https://www.dianping.com/")
driver.find_element_by_xpath("//*[@id=\"top-nav\"]/div[2]/div/div[2]/div/span").click()



driver.find_element_by_xpath("//a[@href='http://s.dianping.com/event/chengdu']").click()

driver.switch_to_new_tab()
driver.find_element_by_xpath("//*[@id=\"s-fix\"]/div[2]/div/div[2]/span").click()

driver.assert_template(Template(r"tpl1573446927123.png", record_pos=(11.505, 6.105), resolution=(100, 100)), "点击烤肉")

driver.airtest_touch(Template(r"tpl1573447085780.png", record_pos=(11.42, 5.695), resolution=(100, 100)))



driver.switch_to_new_tab()

driver.assert_exist("//*[@title='我要报名']", "xpath", "断言我要报名按钮1.")

# # 文字断言
# driver.assert_exist("/html/body/main/div/div/div/div/div/div/span", "xpath", "成功进入airtest官网.")
driver.assert_template(Template(r"tpl1573446501444.png", record_pos=(13.63, 4.39), resolution=(100, 100)), "断言我要报名按钮2")

driver.find_element_by_xpath("//*[@title='我要报名']").click()

driver.snapshot()
driver.switch_to_previous_tab()
driver.switch_to_previous_tab()
driver.back()
driver.forward()





