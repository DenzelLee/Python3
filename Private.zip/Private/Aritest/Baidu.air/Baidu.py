# -*- encoding=utf8 -*-
__author__ = "Administrator"
auto_setup(__file__)

from airtest.core.api import *
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from airtest_selenium.proxy import WebChrome

# 加载驱动
driver = WebChrome()
# 设置隐士等待时间
driver.implicitly_wait(20)

# open新地址
driver.get("https://www.baidu.com/")
driver.find_element_by_id("kw").send_keys("airtest")
driver.find_element_by_xpath("//*[@class='bg s_btn']").click()

driver.find_element_by_xpath("//*[@id=3]/h3/a").click()

driver.switch_to_new_tab()

# 普通点击切换新窗口
driver.switch_to_new_tab()


# 图片识别切换新窗口
driver.airtest_touch(Template(r"tpl1572427671284.png", record_pos=(12.555, 3.725), resolution=(100, 100)))

# 文字断言
driver.assert_exist("/html/body/main/div/div/div/div/div/div/span", "xpath", "成功进入airtest官网.")

# 图片断言
driver.assert_template(Template(r"tpl1572427832133.png", record_pos=(16.11, 3.38), resolution=(100, 100)), "成功匹配官网图片")

driver.quit()					



