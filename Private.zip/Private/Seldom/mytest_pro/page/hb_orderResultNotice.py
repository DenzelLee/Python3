#!/usr/bin/env/python3
# -*- coding:utf-8 -*-
'''
Author:leo
Date&Time:2019/11/19 and 10:30
Project:Python3
FileName:credit
Description：
和包套餐：第四步（借款申请完成后，办理套餐到放款中）
1.办理结果通知
'''
import sys, time, random
sys.path.append(r'D:\Mytest\Python3\Python3\云融项目\和包项目')
from hb_config import Deve_envirment as de
from library.basic import Basic
from mysql.hebao_mysql import hb_mysql

delete_nowTime = time.strftime('%Y-%m-%d %H%M%S', time.localtime(time.time())).split(" ")[0]
# 生成年月日(8)/时分秒(6)/随机整数(3)
nowTime = time.strftime('%Y%m%d %H%M%S', time.localtime(time.time()))
nowdate, nowtime = nowTime.split(" ")[0], nowTime.split(" ")[1]
random_number = str(random.randint(100, 999))

# 获取真实借款订单号
mysql_test = str(hb_mysql().select_info("dev_credit", f"select * from credit_loan_apply where thirdpart_apply_id = '{de.loan_conf['brwOrdNo']}';")).split(",")
orgOrdNo = mysql_test[1]  # 真实借款订单号
print(f"真實訂單號:", type(mysql_test), "真实借款订单号-orgOrdNo：", orgOrdNo)

class Order():
    # 套餐办理结果通知-接口成功后执行，状态变为“待放款”
    def orderResultNotice(self):
        print("\n----开始套餐办理结果通知----")
        headers = {"Content-Type": "application/json", "hsjry-channel-code": "01"}
        payload = {
                    "clientId": de.common_conf['clientId'],
                    "jrnNo": de.common_conf['jrnNo'],
                    # "jrnNo": "20191226001999"+random_number,
                    "requestTm": de.common_conf['requestTm'],
                    "orgOrdNo": orgOrdNo,  # 借款接口成功的响应订单号!!!!!!(必改）
                    # "orgOrdNo": "000LA2019120000000430",  # 借款接口成功的响应订单号!!!!!!(必改）
                    "acpTm": de.common_conf['requestTm'],
                    "modelCode":"CM1234",
                    "appId":"WYRC",
                    "pickCode": "123456",    # !!!不能一样
                    "oprId": "HBYYY0001",
                    "oprMblNo": "18583990002",
                    "depId": "HBYYT0001T",
                    "depNm": "营业厅名称",
                    "mblNo": de.common_user['mblNo'],          # 手机号
                    "groupPictureId": "string",
                    "ticketPictureId": "string",
                    "groupPictureUrl": "http://pic21.nipic.com/20120426/9940080_164340613124_2.jpg",
                    "ticketPictureUrl": "http://pic21.nipic.com/20120426/9940080_164340613124_2.jpg",
                    "brwOrdNo": de.loan_conf['brwOrdNo'],    # 订单号/订单日期
                    # "brwOrdNo": "20191226001999902",    # 订单号/订单日期
                    "brwOrdDt": de.loan_conf['brwOrdDt'],
                }
        a = Basic()
        Request_Body = a.jiami(headers, payload)
        print("\n开始套餐办理结果通知")
        url = f"{de.basic_http['url']}v1/cmpay/orderResultNotice"
        res = a.runapi(url, headers, Request_Body)
        print(f"套餐办理结果通知成功，响应报文如下：\n{res}")
        Response_Body = a.jiemi({"Content-Type": "application/json"}, res)
        user_info = str([key+':'+value for (key,value) in de.common_user.items()])
        loan_info = str([key+':'+value for (key,value) in de.loan_conf.items()])
        a.write_txt("creditApply", "orderResultNotice", user_info+"\n(loan：)"+loan_info+"\n(requ：)"+str(payload).replace("'", '''"''')+"\n(resp：)"+Response_Body+
                    f"\n( 分省信息：){payload['brwOrdNo']}|{payload['brwOrdDt']}|{payload['orgOrdNo']}|jcxf|锦程消费|{de.loan_conf['loanAmt']}|{payload['brwOrdDt']}|123456|{de.common_user['mblNo']}|CM1234|WYRC|HBYYY0001|18583990002|HBYYT0001T|营业厅名称|001|05|"
                    f"\n( 扣款明细：){'20191129001001' + random_number}|{de.loan_conf['brwOrdDt']}|{de.loan_conf['brwOrdNo']}|{de.loan_conf['brwOrdDt']}|F0210|1|1|month_pay_money|1|{payload['orgOrdNo']}|S|{de.common_user['mblNo']}|扣款成功|1|ICBC|1234|101|"
                    f"\n( 退货文件：){payload['brwOrdNo']}|{payload['brwOrdDt']}|{payload['orgOrdNo']}|jcxf|锦程消费|rejected|{de.loan_conf['loanAmt']}|{de.loan_conf['brwOrdDt']}|"
                    f"\n( 退货结算：){payload['brwOrdNo']}|{payload['brwOrdDt']}|jcxf|锦程消费|{de.loan_conf['loanAmt']}|{de.loan_conf['brwOrdDt']}|rejected|"
                    f"\n( 回盘文件：){payload['brwOrdNo']}|{payload['brwOrdDt']}|{payload['orgOrdNo']}|{de.loan_conf['brwOrdDt']}|1|should_repay_month_money|act_repay_month_money|{'20191129001001' + random_number}|{de.loan_conf['brwOrdDt']}|S|对账成功|ICBC|1234|101|"
                    "\n---------------------------------------------借款-----------------------------------------------")
        print("\n请求信息如下：\n"+str(payload).replace("'", '''"''')+"\n"+user_info+"\n"+loan_info+"\n"
                    f"\n( 分省信息：)\n{payload['brwOrdNo']}|{payload['brwOrdDt']}|{payload['orgOrdNo']}|jcxf|锦程消费|{de.loan_conf['loanAmt']}|{payload['brwOrdDt']}|123456|{de.common_user['mblNo']}|CM1234|WYRC|HBYYY0001|18583990002|HBYYT0001T|营业厅名称|001|05|"
                    f"\n( 扣款明细：){'20191129001001'+random_number}|{de.loan_conf['brwOrdDt']}|{de.loan_conf['brwOrdNo']}|{de.loan_conf['brwOrdDt']}|F0210|1|1|month_pay_money|1|{payload['orgOrdNo']}|S|{de.common_user['mblNo']}|扣款成功|1|ICBC|1234|101|"
                    f"\n( 退货文件：){payload['brwOrdNo']}|{payload['brwOrdDt']}|{payload['orgOrdNo']}|jcxf|锦程消费|rejected|{de.loan_conf['loanAmt']}|{de.loan_conf['brwOrdDt']}|"
                    f"\n( 退货结算：){payload['brwOrdNo']}|{payload['brwOrdDt']}|jcxf|锦程消费|{de.loan_conf['loanAmt']}|{de.loan_conf['brwOrdDt']}|rejected|"
                    f"\n( 回盘文件：){payload['brwOrdNo']}|{payload['brwOrdDt']}|{payload['orgOrdNo']}|{de.loan_conf['brwOrdDt']}|1|should_repay_month_money|act_repay_month_money|{'20191129001001'+random_number}|{de.loan_conf['brwOrdDt']}|S|对账成功|ICBC|1234|101|"
              )
        return
if __name__ == "__main__":
    test = Order()
    test.orderResultNotice()

    # 借款申请-待放款-使用中，删除数据（库名称/表名称/sql语句）
    test1 = str(hb_mysql().delete_info("dev_credit", "credit_slice_batch_serial", f"delete from credit_slice_batch_serial where create_time LIKE'{delete_nowTime}%';"))
    test2 = str(hb_mysql().delete_info("dev_credit", "credit_wait_deal_info", f"delete  from credit_wait_deal_info where create_time LIKE'{delete_nowTime}%';"))
    test3 = str(hb_mysql().delete_info("dev_credit", "credit_slice_batch_log", f"delete  from credit_slice_batch_log where create_time LIKE'{delete_nowTime}%';"))

