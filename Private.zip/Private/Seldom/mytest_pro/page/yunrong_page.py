#!/usr/bin/env/python3
# -*- coding:utf-8 -*-
from poium import Page, PageElement

class Login_yunrong(Page):
    """ 登陆"""
    login_name = PageElement(id_="login_username")
    login_password = PageElement(id_="login_password")
    login_button = PageElement(id_="login_button")

class Personal_center(Page):
    """个人中心"""
    # main_frame = PageElement(css="#main")
    daily_link = PageElement(css="div[title='日报填报']")







