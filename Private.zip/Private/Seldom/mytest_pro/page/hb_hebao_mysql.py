#!/usr/bin/env/python3
# -*- coding:utf-8 -*-
'''
Description：
风控回调接口：第二步（授信申请后，查数据库）
1.查询sequenceID
'''
import re
import MySQLdb,sys,json,time,random
sys.path.append(r'D:\Mytest\Python3\Python3\云融项目\和包项目')
from hb_config import Deve_envirment as de
# from hb_config import Test_envirment as de
import MySQLdb.cursors  # 数据库结果以字典类型返回需要connect模块添加“,cursorclass = MySQLdb.cursors.DictCursor”,否则默认返回元组tuple
delete_nowTime = time.strftime('%Y-%m-%d %H%M%S', time.localtime(time.time())).split(" ")[0]  # 公共参数

class hb_mysql():
    def select_info(self, database_name, select_sql):
        # str_data = []
        # 连接Mysql数据库,ip/用户/密码/库名称（形参）/编码
        db = MySQLdb.connect(de.database['host'], de.database['username'], de.database['password'], database_name, charset='utf8')
        cursor = db.cursor()
        try:
            print("\n----查询数据----\n")
            print("sql:", select_sql)
            cursor.execute(select_sql)
        except Exception as e:
            print(f"Exception:{e}")
            # db.rollback()
        # 获取全部数据
        data_all = cursor.fetchall()
        print(f"全部数据：{type(data_all)} {data_all}")
        cursor.close()
        db.close()
        for data in data_all[:]:
            # print(f"遍历数据: {type(data)} {data}")
            # 默认结果取值返回的单引号值’，需要强转str，再替换为”
            str_data = str(data).replace('"', " ").replace("'", ' ').replace(" ", "")
            # print(f"强转数据：{type(str_data)}{str_data}")
        return str_data

    def delete_info(self, database_name, table, delete_sql):
        # 连接Mysql数据库,ip/用户/密码/库名称（形参）/编码
        db = MySQLdb.connect(de.database['host'], de.database['username'], de.database['password'], database_name, charset='utf8')
        cursor = db.cursor()
        try:
            print("\n----删除数据----\n")
            # # 删除数据--删除name=python1的数据
            # delsql = '''DELETE FROM plesson.sq_course WHERE NAME like '测试%';'''
            cursor.execute(f"select * from {table} where create_time LIKE'{delete_nowTime}%';")  # 改日期！！！！
            # 获取全部数据
            data_all = cursor.fetchall()
            for data in data_all[:]:
                print(f"获取全部数据:\n{type(data)} {data}")
            # 删除数据
            cursor.execute(delete_sql)
            db.commit()
        except Exception as e:
            print(f"Exception:{e}")
            db.rollback()
        cursor.close()
        db.close()
        return data_all

    def ks3_modify_dat(self):
        '''分省计划任务的模板格式'''
        fs_dat = f"""
1|1000.99|
{de.common_conf['qryCreditId']}|{de.loan_conf['brwOrdDt']}|000LA20191200000000ab|2020010200001|锦程消费|1000.99|{de.loan_conf['brwOrdDt']}|228001|{de.common_user['mblNo']}|CM1234|WYRC|HBYYY0001|18583990002|HBYYT0001T|营业厅名称|001|05|
@END@ 
        """
        print("\n分省计划任务的模板格式:", fs_dat)
        return fs_dat
if __name__ == "__main__":
    # # 风控审核的ID和订单号：
    # mysql_test_riskCallBack = str(hb_mysql().select_info("dev_credit", f"SELECT * FROM credit_risk_flow WHERE third_apply_id='{de.common_conf['qryCreditId']}';")).split(",")
    # print(type(mysql_test_riskCallBack), mysql_test_riskCallBack[1], mysql_test_riskCallBack[4])
    # sequenceId = mysql_test_riskCallBack[1]
    # thirdApplyId = mysql_test_riskCallBack[4]
    # print(type(sequenceId), f"sequenceId：" + sequenceId, f"thirdApplyId：" + thirdApplyId)

    # 自动风控状态（1.初始化；2.审核中；3.审核成功；4.审核失败）：
    credit_riskCallBack_stutas = re.sub(r'\D', "", str(hb_mysql().select_info("dev_credit", f"select status from credit_apply where thirdpart_apply_id = '{de.common_conf['qryCreditId']}';")))
    print(type(credit_riskCallBack_stutas), "自动风控状态为：", credit_riskCallBack_stutas)
    # # 获取真实借款订单号
    # mysql_test1 = str(hb_mysql().select_info("dev_credit", f"select * from credit_loan_apply where thirdpart_apply_id = '{de.loan_conf['brwOrdNo']} ';")).split(",")
    # orgOrdNo = mysql_test1[1]
    # print("获取数据：", type(mysql_test1),  "真实借款订单号-orgOrdNo：", orgOrdNo)

    # 借款申请-待放款-使用中，删除数据（库名称/表名称/sql语句）
    # test1 = str(hb_mysql().delete_info("dev_credit", "credit_slice_batch_serial", f"delete from credit_slice_batch_serial where create_time LIKE'{delete_nowTime}%';"))
    # test2 = str(hb_mysql().delete_info("dev_credit", "credit_wait_deal_info", f"delete  from credit_wait_deal_info where create_time LIKE'{delete_nowTime}%';"))
    # test3 = str(hb_mysql().delete_info("dev_credit", "credit_slice_batch_log", f"delete  from credit_slice_batch_log where create_time LIKE'{delete_nowTime}%';"))

