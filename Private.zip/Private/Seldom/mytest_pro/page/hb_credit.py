#!/usr/bin/env/python3
# -*- coding:utf-8 -*-
'''
Author:leo
Date&Time:2019/11/19 and 10:30
Project:Python3
FileName:credit
Description：
授信模块：第一步（授信申请）
1.授信申请（成功）：修改hb_config模块的环境类的common_conf字典参数（qryCreditId）。
2.风控回调（搁浅）：接口报错，验证签名失败，暂时无法使用。
3.授信申请结果查询（成功）：
'''
import requests, json, sys, time, random, re
sys.path.append(r'D:\Mytest\Python3\Python3\Seldom\mytest_pro')
from hb_config import Deve_envirment as de
from library.basic import Basic
from hb_hebao_mysql import hb_mysql

# 生成年月日(8)/时分秒(6)/随机整数(3)
nowTime = time.strftime('%Y%m%d %H%M%S', time.localtime(time.time()))
nowdate, nowtime = nowTime.split(" ")[0], nowTime.split(" ")[1]
random_number = str(random.randint(100, 999))

class Credit_granting():
    # 授信申请
    def creditApply(self):
        print("\n----开始授信申请----")
        headers = {"Content-Type": "application/json", "hsjry-channel-code": "01"}
        payload = {
                    "clientId": de.common_conf['clientId'],    # 商户号（写死）
                    "jrnNo": de.common_conf['jrnNo'],   # 流水号
                    "requestTm": de.common_conf['requestTm'],  # 请求日期
                    "productId": "F02113",  # 产品编号
                    "actOrgId": "2020010200001",

                    "qryCreditId": de.common_conf['qryCreditId'],  # 三方授信流水，唯一（修改）
                    "hbUsrNo": de.common_conf['hbUsrNo'],       # 和包贷款用户号（1个身份证支持一个和包用户，切换身份证，必须换和包账户）
                    "appId": "WYRC",                         # 渠道编码（FLXX：纷领信息，WYRC：无忧融创，SJYT：世纪银通）-由锦程提供分配
                    "mblNo": de.common_user['mblNo'],           # 用户注册手机号
                    "usrIdName":de.common_user['usrIdName'],     # 用户身份证姓名
                    "usrIdCard": de.common_user['usrIdCard'],          # 用户身份证号码
                    "idCardFrontID":"20191021000112",
                    "idCardBackID":"20191021000113",
                    "livePictureID":"20191104",
                    # 身份证正面（国徽）/反面（人头），这里是反的。
                    # "idCardFrontUrl":"http://pic21.nipic.com/20120426/9940080_164340613124_2.jpg",
                    # "idCardFrontUrl":"http://ks3-cn-beijing.ksyun.com/jccfc-demo/xdgl/3377862963649175553_11.jpg?AccessKeyId=AKLTvcv73sl5Q0yZRiBo5V0bZw&Expires=1587510644&Signature=%2FptO5QtiEYxXxptGTYQI1viSKbs%3D",
                    # "idCardBackUrl":"http://pic21.nipic.com/20120426/9940080_164340613124_2.jpg",
                    # "idCardBackUrl":"http://ks3-cn-beijing.ksyun.com/jccfc-demo/xdgl/3377862963649175554_14.jpg?AccessKeyId=AKLTvcv73sl5Q0yZRiBo5V0bZw&Expires=1587510670&Signature=SdeeXW8FNycp8NLp1FhfMJdYdGM%3D",
                    "idCardFrontUrl": "http://jccfc-dev.ks3-cn-beijing.ksyun.com/xdgl/ydhb/yw/wyrc/20191216/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_201912111907%E6%AD%A3.jpg",
                    "idCardBackUrl": "http://jccfc-dev.ks3-cn-beijing.ksyun.com/xdgl/ydhb/yw/wyrc/20191216/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_201912111907%E5%8F%8D.jpg",
                    "livePictureUrl": "http://pic21.nipic.com/20120426/9940080_164340613124_2.jpg",
                    "zipCode": "610000",                       # 邮政编码
                    # "addressCode": "30991650103",               # 家庭住址编码（新疆自治区乌鲁木齐市杀依巴克区）
                    "addressCode": "22280510104",             # 家庭住址编码（四川省成都市锦江区）
                    # "addressCode": "19760442000",             # 家庭住址编码（广东省中山市）
                    "address": "春熙路太古里1栋1单元1号爱马仕（Py）",
                    "inCome": "001",                              # 收入区间(001-007)
                    "usrJob": "001",                            # 用户工作类型（001-021）
                    "contactName": "联系人一",
                    "contactMblNo": "18583990001",
                    "contactRelation": "001",                   # 关系（001-009）
                    "bankCardNo": de.common_user['bankCardNo'],
                    "bankCardName": de.common_user['usrIdName'],
                    "bankMblNo": de.common_user['mblNo'],
                    # "bankCode": "01020000",  # 银行卡编码
                    "bankCode": "ICBC",  # 银行卡编码
                    "companyName": "锦程有限公司",
                    "companyAddress": "四川省成都市中航Acc1栋2单元3号",
                    # "companyAddressCode": "21898469030",        # 公司住址编码（海南省海口市琼中黎族苗族自治县）
                    "companyAddressCode": "22280510104",        # 公司住址编码（四川省成都市锦江区）
                    "companyMblNo": "028-88888888",
                    "schooling": "001",                         # 学历（001-007，博士到初中）
                    "socialIdentity": "001",                    # 社会身份（001-004，企业到待业）
                    "maritalSta": "0",                          # 婚姻（0-1，未婚到已婚）
                    "idExpDt": "20201230",                      # 身份证有效期
                    "country": "中国",
                    "nation": "汉",
                    "cusSex": "1",                              # 性别（0-2，女男未知）
                    "contactName1": "联系人二",
                    "contactMblNo1": "18583990002",
                    # "contactRelation1": "002",
                    "contactRelation1": "003",
                    "contactName2": "联系人三",
                    "contactMblNo2": "18583990003",
                    # "contactRelation2": "003",
                    "contactRelation2": "004",
                    "richScore":"",                       # 财富分（财富分=（额度-500）/50+600，低于1000可以为空字符
                    "content":{
                        "liveOrgNm": "活体识别结构名称",
                        "liveOrgId": "20200101",
                        "liveScore": "10",
                        "hbScore": "20",
                        "creditTotScore": "30",
                        "creditModScore": "40",
                        "oprId": "HBYYY0001",                     # 营业员编号
                        "oprMblNo": "18583990002",          # 营业员手机号
                        "regDt": "20200101",                # 注册日期
                        # "userType": "F02142",               # 用户准入结果（-1非移动用户，-2数据异常，0不准入，1满足最大公约数，2全满足，默认空为0）
                        "userType": "2",                      # 用户准入结果（-1非移动用户，-2数据异常，0不准入，1满足最大公约数，2全满足，默认空为0）
                        "userStarLvl": "1",                 # 用户星级
                        "applyModelCode": "CM1234",            # 用户借款申请手机串码
                        "applyIp": "192.168.0.1",           # 用户借款申请IP地址
                        "userMail": "270980001@qq.com",
                        "totalBonusAmt":100.50,             # 总红包额
                        "applseq": "20200101",              # 签章流水号
                        "usrProvNo": "01"                   # 用户归属省份（修改为2位）
                    }
                }
        a = Basic()
        Request_Body = a.jiami(headers, payload)
        print("\n开始授信申请")
        url = f"{de.basic_http['url']}v1/cmpay/creditApply"
        res = a.runapi(url, headers, Request_Body)
        print(f"授信申请成功，响应报文如下：\n{res}")
        Response_Body = a.jiemi({"Content-Type": "application/json"}, res)
        # reqeust_info = str([key + ':' + value for (key, value) in json.dumps(payload).items()])
        user_info = str([key+':'+value for (key, value) in de.common_user.items()])
        a.write_txt("creditApply", "creditApply", user_info+"\n(requ：)"+str(payload).replace("'", '''"''')+"\n(resp：)"+Response_Body)
        print("\n请求信息如下：\n"+str(payload).replace("'", '''"''')+"\n"+user_info)
        return de.common_conf['qryCreditId']

    # 风控回调
    def riskCallBack(self):
        # 风控审核的ID和订单号：
        print("\n----开始风控回调----")
        mysql_test_riskCallBack = str(hb_mysql().select_info("dev_credit", f"SELECT * FROM credit_risk_flow WHERE third_apply_id='{de.common_conf['qryCreditId']}';")).split(",")
        print(type(mysql_test_riskCallBack), mysql_test_riskCallBack[1], mysql_test_riskCallBack[4])
        sequenceId = mysql_test_riskCallBack[1]
        thirdApplyId = mysql_test_riskCallBack[4]
        print(type(sequenceId), f"sequenceId："+sequenceId, f"thirdApplyId："+thirdApplyId)
        headers = {
            "Content-Type": "application/json",
            "hsjry-channel-code": "01",
            "User-Agent": "PostmanRuntime/7.20.1",
            # "User-Agent": "Apache-HttpClient/4.5.5 (Java/1.8.0_101)",
            # "Accept": "*/*",
            # "Cache-Control": "no-cache",
            # "Postman - Token": "77a73b2c-921d-4c97-aae4-bb2f2609a1ba",
            # "Host": "api-web-dev.jccfc.com",
            # "Accept-Encoding": "gzip, deflate",
            # "Content-Length": "843",
            # "Cookie": "__jsluid_s=c56b35bc420ed5d07033837411c26171",
            # "Connection": "keep-alive"
        }
        # 代理配置
        # headers = {"Content - Type": "application/json", "hsjry - channel - code": "01"}
        # proxies = {
        #     "http": "http://192.168.1.110:55835",
        #     "https": "https://192.168.1.110:55835",
        # }
        # cookies = {"__jsluid_s": "c56b35bc420ed5d07033837411c26171"}
        # cookies = {"Cookie": "__jsluid_s=c56b35bc420ed5d07033837411c26171"}
        payload = {
                  "body": {
                    "responseCode": "0000",
                    "responseMsg": "同意",
                    "sequenceId": sequenceId,
                    "thirdApplyId": thirdApplyId,
                    # "sequenceId": "1575364872135-97912063",
                    # "thirdApplyId": "20191203001000009",
                    "finalScore": 100,
                    "finalDecision": "A",
                    "finalDealType": "",
                    "finalDealTypeName": "风控审核通过",
                    "spendTime": "20191127",
                    "pbocWorkunit": "01",
                    "initLimith": "10000"
                  },
                  "head":{
                    "channelNo": "01",
                    "deviceId": "string",
                    "empNo": "string",
                    "latitude": 0,
                    "longitude": 0,
                    "marketClue": "string",
                    "merchantId": "000UC010000003041",
                    "notifyUrl": None,
                    "organId": "string",
                    "rebackUrl": "string",
                    "requestSerialNo": "2020010100100"+nowtime,  # 流水号必须不唯一，每次更改
                    "requestTime": "string",
                    "tenantId": "000",
                    "token": "123143245"
                  }
                }

        # url = f"{de.basic_http['url']}v1/risk/riskCallBack"
        url = "https://api-web-dev.jccfc.com/api/fql/v1/risk/riskCallBack"
        response = requests.post(url=url, headers=headers, json=payload)
        # res_json() = response.json()
        res_text = response.text
        res_headers = str(response.headers)
        res_status_code = str(response.status_code)
        res_request = str(response.request)
        res_raw = str(response.raw)
        user_info = str([key+':'+value for (key, value) in de.common_user.items()])
        Basic().write_txt("creditApply", "creditApply", user_info+"\n(requ：)"+str(payload).replace("'", '''"''')+"\n(resp：)"+str(res_text))
        print("\n请求信息如下：\n"+str(headers)+"\n"+str(payload).replace("'", '''"''')+"\n"+user_info)
        print(f"\n风控回调成功，响应报文如下：", "\nres_headers    ："+str(res_headers)+"\nres_status_code："+str(res_status_code)+"\nres_request    ："+str(res_text))
        return
    # 风控回调1
    def riskCallBack1(self):
        # 风控审核的ID和订单号：
        print("\n----开始风控回调----")
        mysql_test_riskCallBack = str(hb_mysql().select_info("dev_credit", f"SELECT * FROM credit_risk_flow WHERE third_apply_id='{de.common_conf['qryCreditId']}';")).split(",")
        print(type(mysql_test_riskCallBack), mysql_test_riskCallBack[1], mysql_test_riskCallBack[4])
        sequenceId = mysql_test_riskCallBack[1]
        thirdApplyId = mysql_test_riskCallBack[4]
        print(type(sequenceId), f"sequenceId："+sequenceId, f"thirdApplyId："+thirdApplyId)
        headers = {
            "Content-Type": "application/json",
            "hsjry-channel-code": "01",
            "User-Agent": "PostmanRuntime/7.20.1",
        }
        payload = {
                    "code": "0000",
                    "policyResult": {
                        "finalScore": 0,
                        "customPolicyResult": {
                          "initLimith": "10000",
                          "pbocWorkunit": "四川成都"
                        },
                        "finalDecision": "Accept",
                        "finalDealType": "FQLNO1",
                        "finalDealTypeName": "锦囊贷分期乐一个月内不能申请",
                        "rejectCodes": [],
                        "seqId": sequenceId,
                        "spendTime": nowdate
                    },
                    "desc": "success"
                }

        # url = f"{de.basic_http['url']}v1/risk/riskCallBack"
        url = "https://api-web-dev.jccfc.com/api/fql/v1/risk/riskCallBack"
        response = requests.post(url=url, headers=headers, json=payload)
        # res_json() = response.json()
        res_text = response.text
        res_headers = str(response.headers)
        res_status_code = str(response.status_code)
        res_request = str(response.request)
        res_raw = str(response.raw)
        user_info = str([key+':'+value for (key, value) in de.common_user.items()])
        Basic().write_txt("creditApply", "creditApply", user_info+"\n(requ：)"+str(payload).replace("'", '''"''')+"\n(resp：)"+str(res_text))
        print("\n请求信息如下：\n"+str(headers)+"\n"+str(payload).replace("'", '''"''')+"\n"+user_info)
        print(f"\n风控回调成功，响应报文如下：", "\nres_headers    ："+str(res_headers)+"\nres_status_code："+str(res_status_code)+"\nres_request    ："+str(res_text))
        return
    # 风控回调2
    def riskCallBack2(self):
        # 风控审核的ID和订单号：
        print("\n----开始风控回调----")
        mysql_test_riskCallBack = str(hb_mysql().select_info("dev_credit", f"SELECT * FROM credit_risk_flow WHERE third_apply_id='{de.common_conf['qryCreditId']}';")).split(",")
        print(type(mysql_test_riskCallBack), mysql_test_riskCallBack[1], mysql_test_riskCallBack[4])
        sequenceId = mysql_test_riskCallBack[1]
        thirdApplyId = mysql_test_riskCallBack[4]
        print(type(sequenceId), f"sequenceId："+sequenceId, f"thirdApplyId："+thirdApplyId)
        headers = {
            "Content-Type": "application/json",
            "hsjry-channel-code": "01",
            "User-Agent": "PostmanRuntime/7.20.1",
        }
        payload = {
                    "code": "0000",
                    "policyResult": {
                        "finalScore": 0,
                        "customPolicyResult": {
                          "initLimith": "100",
                          "pbocWorkunit": "四川成都"
                        },
                        "finalDecision": "Accept",
                        "finalDealType": "FQLNO1",
                        "finalDealTypeName": "锦囊贷分期乐一个月内不能申请",
                        "rejectCodes": [],
                        "seqId": sequenceId,
                        "spendTime": nowdate
                    },
                    "desc": "success"
                }

        # url = f"{de.basic_http['url']}v1/risk/riskCallBack"
        url = "https://api-web-dev.jccfc.com/api/fql/v1/risk/riskCallBack"
        response = requests.post(url=url, headers=headers, json=payload)
        # res_json() = response.json()
        res_text = response.text
        res_headers = str(response.headers)
        res_status_code = str(response.status_code)
        res_request = str(response.request)
        res_raw = str(response.raw)
        user_info = str([key+':'+value for (key, value) in de.common_user.items()])
        Basic().write_txt("creditApply", "creditApply", user_info+"\n(requ：)"+str(payload).replace("'", '''"''')+"\n(resp：)"+str(res_text))
        print("\n请求信息如下：\n"+str(headers)+"\n"+str(payload).replace("'", '''"''')+"\n"+user_info)
        print(f"\n风控回调成功，响应报文如下：", "\nres_headers    ："+str(res_headers)+"\nres_status_code："+str(res_status_code)+"\nres_request    ："+str(res_text))
        return
    # 自动风控1
    def riskCallBack3(self):
        # 风控审核的ID和订单号：12.28
        print("\n----开始风控回调----")
        mysql_test_riskCallBack = str(hb_mysql().select_info("dev_credit", f"SELECT * FROM credit_risk_flow WHERE third_apply_id='{de.common_conf['qryCreditId']}';")).split(",")
        print(type(mysql_test_riskCallBack), mysql_test_riskCallBack[1], mysql_test_riskCallBack[4])
        sequenceId = mysql_test_riskCallBack[1]
        thirdApplyId = mysql_test_riskCallBack[4]
        print(type(sequenceId), f"sequenceId："+sequenceId, f"thirdApplyId："+thirdApplyId)
        headers = {
            "Content-Type": "application/json",
            "hsjry-channel-code": "01",
            "User-Agent": "PostmanRuntime/7.20.1",
        }

        payload = {
                      "code": "0000",
                      "desc": "success",
                      "policyResult": {
                        "seqId": sequenceId,
                        "finalDecision": "Accept",
                        "finalScore": 0,
                        "finalDealType": "",
                        "finalDealTypeName": "风控审核通过",
                        "spendTime": nowdate,
                        "customPolicyResult": {
                          "initLimith": 10000.0,
                          "pbocWorkunit": ""
                        }
                      }
                    }
        # url = f"{de.basic_http['url']}v1/risk/riskCallBack"
        url = "https://api-web-dev.jccfc.com/api/fql/v1/risk/riskCallBack"
        response = requests.post(url=url, headers=headers, json=payload)
        # res_json() = response.json()
        res_text = response.text
        res_headers = str(response.headers)
        res_status_code = str(response.status_code)
        res_request = str(response.request)
        res_raw = str(response.raw)
        user_info = str([key+':'+value for (key, value) in de.common_user.items()])
        Basic().write_txt("creditApply", "creditApply", user_info+"\n(requ：)"+str(payload).replace("'", '''"''')+"\n(resp：)"+str(res_text))
        print("\n请求信息如下：\n"+str(headers)+"\n"+str(payload).replace("'", '''"''')+"\n"+user_info)
        print(f"\n风控回调成功，响应报文如下：", "\nres_headers    ："+str(res_headers)+"\nres_status_code："+str(res_status_code)+"\nres_request    ："+str(res_text))
        return
    #  最近一次风控12.28
    def aotu_riskCallBack1(self):
        #  查询自动风控的状态（1.初始化；2.审核中；3.审核成功；4.审核失败）
        change_gitlab_nowTime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
        print("\n----开始自动风控审核，请等候----", str(change_gitlab_nowTime))
        credit_riskCallBack_stutas = "01"
        while credit_riskCallBack_stutas != "03":
            Basic().progress_bar_wait_time(10)
            credit_riskCallBack_stutas = re.sub(r'\D', "", str(hb_mysql().select_info("dev_credit", f"select status from credit_apply where thirdpart_apply_id = '{de.common_conf['qryCreditId']}';")))
            print(type(credit_riskCallBack_stutas), "(每10秒轮循）当前自动风控状态为：", credit_riskCallBack_stutas)
        print("\n----完成自动风控审核，请继续----", str(change_gitlab_nowTime))
    # 自动风控2(加统计时间）
    def aotu_riskCallBack2(self):
        import time
        def wait_timer(func):
            def wrapper(*args, **kwds):
                t0_time = time.time()
                func(*args, **kwds)
                t1_time = time.time()
                print('----Total耗时：%0.2f ----' % (t1_time - t0_time,))
            return wrapper
        # 装饰器时间差:@加函数名约等于执行wait_timer（do_something(delay_time)），把下一个整个函数作为上一个函数参数传递，并执行。
        @wait_timer
        def do_something():
            #  查询自动风控的状态（1.初始化；2.审核中；3.审核成功；4.审核失败）
            change_gitlab_nowTime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
            print("\n----开始自动风控审核，请等候----", str(change_gitlab_nowTime))
            credit_riskCallBack_stutas = "01"
            while credit_riskCallBack_stutas != "03":
                Basic().progress_bar_wait_time(10)
                credit_riskCallBack_stutas = re.sub(r'\D', "", str(hb_mysql().select_info("dev_credit", f"select status from credit_apply where thirdpart_apply_id = '{de.common_conf['qryCreditId']}';")))
                print(type(credit_riskCallBack_stutas), "(每10秒轮循）当前自动风控状态为：", credit_riskCallBack_stutas)
            print("\n----完成自动风控审核，请继续----", str(change_gitlab_nowTime))
        do_something()
    # 授信申请结果查询
    def creditApplyQuery(self):
        print("\n----开始授信申请结果查询----")
        headers = {"Content-Type": "application/json", "hsjry-channel-code": "01"}
        payload = {
            "clientId": de.common_conf['clientId'],
            "jrnNo": de.common_conf['jrnNo'],
            "requestTm": de.common_conf['requestTm'],

            "qryCreditId": de.common_conf['qryCreditId'],
            "hbUsrNo": de.common_conf['hbUsrNo'],
            "appId": "WYRC"
        }
        a = Basic()
        Request_Body = a.jiami(headers, payload)
        print("\n开始授信申请结果查询")
        url = f"{de.basic_http['url']}v1/cmpay/creditApplyQuery"
        headers = headers
        response = requests.post(url=url, headers=headers, data=Request_Body)
        res = response.json()
        res_credit = str(res).replace("'", '''"''').replace(" ", "")
        print(f"授信申请结果查询成功，响应报文如下：\n{res_credit}")
        Response_Body = a.jiemi({"Content-Type": "application/json"}, res_credit)
        # reqeust_info = str([key + ':' + value for (key, value) in payload.items()])
        user_info = str([key+':'+value for (key,value) in de.common_user.items()])
        a.write_txt("creditApply", "creditApplyQuery", user_info+"\n(requ：)"+str(payload).replace("'", '''"''')+"\n(resp：)"+Response_Body)
        print("\n请求信息如下：\n"+str(payload).replace("'", '''"''')+"\n"+user_info)
        return
if __name__ == "__main__":
    test = Credit_granting()
    test.creditApply()
    # test.aotu_riskCallBack2()
    # test.riskCallBack3()  # 最新

    # Basic().progress_bar_wait_time(35)  # time.sleep(30)
    # test.riskCallBack()
    # test.creditApplyQuery()
