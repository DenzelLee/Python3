#!/usr/bin/env/python3
# -*- coding:utf-8 -*-
'''
Author:leo
Date&Time:2019/11/19 and 10:30
Project:Python3
FileName:credit
Description：
借款模块：第三步（授信-风控成功，借款申请）
1.借款申请
2.借款申请结果查询
'''
import datetime, time
from pprint import pprint
import requests,json
import sys, time, random
sys.path.append(r'D:\Mytest\Python3\Python3\云融项目\和包项目')
from hb_config import Deve_envirment as de
from library.basic import Basic

nowTime = time.strftime('%Y%m%d %H%M%S', time.localtime(time.time()))
nowdate, nowtime = nowTime.split(" ")[0], nowTime.split(" ")[1]
random_number = str(random.randint(100, 999))
# loan_conf = {"brwOrdNo": "201911220100001", "brwOrdDt": "20191122", "orgOrdNo": "000LA2019112200100001"}

class Loan():
    # 借款申请
    def loanApply(self):
        print("\n----开始借款申请----")
        headers = {"Content-Type": "application/json", "hsjry-channel-code": "01",
                   "notifyUrl":"http://pic21.nipic.com/20120426/9940080_164340613124_2"}
        payload = {
                    "clientId": de.common_conf['clientId'],
                    "jrnNo": de.common_conf['jrnNo'],
                    # "jrnNo": "20191226001999"+random_number,
                    "requestTm": de.common_conf['requestTm'],
                    "mblNo": de.common_user['mblNo'],                 # 用户手机号
                    "hbUsrNo": de.common_conf['hbUsrNo'],
                    "brwOrdNo": de.loan_conf['brwOrdNo'],      # 和包贷借款订单号
                    # "brwOrdNo": "20191226001999904",      # 和包贷借款订单号
                    "appId": "WYRC",                        # 渠道编码（FLXX：纷领信息，WYRC：无忧融创，SJYT：世纪银通）-由锦程提供分配

                    "brwOrdDt": de.loan_conf['brwOrdDt'],      # 和包贷借款订单日期,借款申请日
                    "loanAmt": float(de.loan_conf['loanAmt']),                   # 贷款金额/月份
                    "loanMonth": "24",
                    "busTyp": "0",                          # 业务类型（0非终端7天有效，1终端2天有效）
                    "actBrwMblNo": de.common_user['mblNo'],           # 合约手机号（实际借款手机号）
                    "actBrwHbUsrNo": de.common_conf['hbUsrNo'],  # 实际借款和包ID
                    "actBrwIdNo": de.common_user['usrIdCard'],    # 实际借款用户身份证号
                    "actualOrgId": "2020010100001",         # 实际借款出资方编号
                    "provStgDay": "05",                     # 省份账单日(05，即下月还款日)
                    "actOrgId": "2020010200001",
                    "depProvNo": "01",                      # 营业厅省份编号（放款计划任务模板有用）
                    "content":{
                        "productNm": "土豪金套餐描述",     # 套餐信息
                        # "productId": "F0210",
                        "productId": "F02113",
                        "pkgAmt": 10000,
                        "goodId": "HBSP0001",               # 商品信息
                        "goodNm": "和包-商品名称",
                        "oprId": "HBYYY0001",               # 营业员信息
                        "oprMblNo": "18583990002",
                        "oprCusNm": "营业员姓名",
                        "depId": "HBYYT0001T",             # 营业厅信息
                        "depNm": "营业厅名称",
                        "depMngMblNo": "18583990001",       # 营业厅负责人手机号
                        "depCityNo": "100",                 # 营业厅地市编号/区域编号
                        "depRegNo": "110101",
                        "applyModelCode": "CM1234",       # 用户信息
                        "applyIp":"192.168.0.1",
                        "mercId": "000UC010000003041",      # 门店信息
                        "mercNm": "中移分期测试信息有限公司",
                        "mngModel": "001",                  # 经验模式（001-006，自营到下单门店）
                        "depMngCusNm": "门店负责人姓名"
                    }
                }
        a = Basic()
        Request_Body = a.jiami(headers, payload)  # 加密
        print("\n开始借款申请")
        url = f"{de.basic_http['url']}v1/cmpay/loanApply"
        res = a.runapi(url, headers, Request_Body)
        print(f"借款申请成功，响应报文如下：\n{res}")
        Response_Body = a.jiemi({"Content-Type": "application/json"}, res)  # 解密
        # reqeust_info = str([key + ':' + value for (key, value) in de.common_conf.items()])
        user_info = str([key+':'+value for (key,value) in de.common_user.items()])
        loan_info = str([key+':'+value for (key,value) in de.loan_conf.items()])
        a.write_txt("creditApply", "loanApply", user_info+"\n(loan：)"+loan_info+"\n(requ：)"+str(payload).replace("'", '''"''')+"\n(resp：)"+Response_Body)
        print("\n请求信息如下：\n"+str(payload).replace("'", '''"''')+"\n"+user_info+"\n"+loan_info)
        return

    # 借款申请结果查询
    def loanApplyQuery(self):
        print("\n----开始借款申请结果查询----")
        headers = {"Content-Type": "application/json", "hsjry-channel-code": "01"}
        payload = {
                    "clientId": de.common_conf['clientId'],
                    "jrnNo": de.common_conf['jrnNo'],
                    "requestTm": de.common_conf['requestTm'],

                    "brwOrdNo": de.loan_conf['brwOrdNo'],
                    "brwOrdDt": de.loan_conf['brwOrdDt'],
                    "orgOrdNo": de.loan_conf['orgOrdNo'],
                    "brwAmt": 100,
                    "appId": "WYRC"
        }
        a = Basic()
        Request_Body = a.jiami(headers, payload)
        print("\n开始借款申请结果查询")
        url = f"{de.basic_http['url']}v1/cmpay/loanApplyQuery"
        headers = headers
        response = requests.post(url=url, headers=headers, data=Request_Body)
        res = response.json()
        res_credit = str(res).replace("'", '''"''').replace(" ", "")
        print(f"借款申请结果查询成功，响应报文如下：\n{res_credit}")
        Response_Body = a.jiemi({"Content-Type": "application/json"}, res_credit)
        # reqeust_info = str([key + ':' + value for (key, value) in de.common_conf.items()])
        user_info = str([key+':'+value for (key,value) in de.common_user.items()])
        loan_info = str([key+':'+value for (key,value) in de.loan_conf.items()])
        a.write_txt("creditApply", "loanApplyQuery", user_info+"\n(loan：)"+loan_info+"\n(requ：)"+str(payload).replace("'", '''"''')+"\n(resp：)"+Response_Body)
        print("\n请求信息如下：\n"+str(payload).replace("'", '''"''')+"\n"+user_info+"\n"+loan_info)
if __name__ == "__main__":
    test = Loan()
    test.loanApply()
    # test.loanApplyQuery()