#!/usr/bin/env/python3
# -*- coding:utf-8 -*-
'''
Author:leo
Date&Time:2019/11/16 and 19:36
Project:Python3
FileName:config
Description：...
'''
import datetime, time,random
import sys
sys.path.append(r'D:\Mytest\Python3\Python3\Seldom\mytest_pro')
from library.get_info import Get_information
# 获取当前格式化-年月日：时分秒
nowTime = time.strftime('%Y%m%d %H%M%S', time.localtime(time.time()))
# 生成年月日(8)/时分秒(6)/随机整数(5)
nowdate, nowtime = nowTime.split(" ")[0], nowTime.split(" ")[1]
random_number = str(random.randint(51, 999))
# 变量
# num = random_number
# print(num)
# user_num, num = 357, "17"
user_num, num = 367, "17"



# get_one_info = Get_txt().read_info("user_info50.txt", "21")
get_one_info = Get_information().read_txt("user_info1000.txt", str(user_num))
# get_one_info = Get_information().read_txt("user_info1000.txt", "107")
info_name, info_carid, info_bankid, info_phone = get_one_info[0], get_one_info[1], get_one_info[2], get_one_info[3]
print(info_name, info_carid, info_bankid, info_phone)

# 内部开发配置(dev)
class Deve_envirment():
	database   = {"host" : "rm-2vc581g0h5rua01s1.mysql.cn-chengdu.rds.aliyuncs.com",
				"port" : "3306", "database_name" : "dev_credit",
				"username" : "dev_core_account", "password" : "NHnq&ZHGcjpjH82g"}
	basic_http = {"url": "https://router-dev.jccfc.com/api/", "port": "8080", "timeout": "1.0"}
	jiami_http = {"url": "https://router-dev.jccfc.com/pkt/tool/encrypt"}
	jiemi_http = {"url": "https://router-dev.jccfc.com/pkt/tool/decrypt"}
	# count    = {"username": "hundsun", "password": "111111"}

	# 公共参数（接口）：①改和包号（1和包不能对多个身份证）；②改日期后缀；三.改用户四要素号码
	common_conf = {"clientId": "000UC010000003041", "qryCreditId": nowdate+"0010010"+num, "hbUsrNo": nowdate[-4:]+num, "jrnNo": nowdate+"0010011"+num, "requestTm": nowdate}
	common_user = {"usrIdName": info_name, "usrIdCard": info_carid, "bankCardNo": info_bankid, "mblNo": info_phone}
	# common_user = {"usrIdName": "曹自军", "usrIdCard": "411424198803199233", "bankCardNo": "6217994910129690352", "mblNo": "18736865587"}
	loan_conf = {"loanAmt": "1000.01", "brwOrdNo": nowdate+"0010020"+num, "brwOrdDt": nowdate, "orgOrdNo": "000LA"+nowdate+"0010020"+num}
	# loan_conf = {"brwOrdNo": "20191202001001101", "brwOrdDt": date, "orgOrdNo": "000LA20191202001001101"}


# 内部测试环境
class Test_envirment():
	database = {"host": "rm-2vc877ew28n04iar7.mysql.cn-chengdu.rds.aliyuncs.com",
				"port": "3306", "database_name": "sit_user",
				"username": "loan", "password": "test201988"}

	http     = {"login_url": "https://cms-uat.corp.jccfc.com/jclogin/login.html",
				"port": "8080", "timeout": "1.0"}

	count    = {"username": "hundsun", "password": "111111"}

# 内部生产环境
class Prod_envirment():
	pass

if __name__ =="__main__":
	print("\n---- 配置变量如下 ----", end="")
	common_conf = str([key+':'+value for (key, value) in Deve_envirment.common_conf.items()])
	common_user = str([key+':'+value for (key, value) in Deve_envirment.common_user.items()])
	loan_conf = str([key+':'+value for (key, value) in Deve_envirment.loan_conf.items()])
	print("\ncommon_conf:"+common_conf, "\ncommon_user:" + common_user, "\nloan_conf  :" + loan_conf)
