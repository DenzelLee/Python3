#!/usr/bin/env/python3
# -*- coding:utf-8 -*-
from poium import Page, PageElement

class Login_jincheng(Page):
    """ 登陆"""
    login_name = PageElement(css='.input-outer>[name="login-name"]')
    login_password = PageElement(css='.input-outer>[name="login-pass"]')
    login_button = PageElement(css='.act-but.submit')

class Personal_center(Page):
    pass







