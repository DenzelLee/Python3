#!/usr/bin/env/python3
# -*- coding:utf-8 -*-
'''
Author:leo
Date&Time:2019/12/6 and 17:16
Description：...
1.授信申请-风控审核-接款申请-套餐通知-状态：放款中。
'''
import time
from 和包项目.library.basic import Basic
from 和包项目.mysql.hebao_mysql import hb_mysql
from 和包项目.testcase.testApi.credit import Credit_granting

# 授信+等候时间+风控
test1 = Credit_granting()
test1.creditApply()
test1.aotu_riskCallBack2()
test1.creditApplyQuery()

from 和包项目.testcase.testApi.loan import Loan
test2 = Loan()  # 借款
test2.loanApply()
test2.loanApplyQuery()

from 和包项目.testcase.testApi.orderResultNotice import Order
time.sleep(1)
test3 = Order()  # 套餐通知
test3.orderResultNotice()

# 分省前删数据
delete_nowTime = time.strftime('%Y-%m-%d %H%M%S', time.localtime(time.time())).split(" ")[0]
test1 = str(hb_mysql().delete_info("dev_credit", "credit_slice_batch_serial", f"delete from credit_slice_batch_serial where create_time LIKE'{delete_nowTime}%';"))
test2 = str(hb_mysql().delete_info("dev_credit", "credit_wait_deal_info", f"delete  from credit_wait_deal_info where create_time LIKE'{delete_nowTime}%';"))
test3 = str(hb_mysql().delete_info("dev_credit", "credit_slice_batch_log", f"delete  from credit_slice_batch_log where create_time LIKE'{delete_nowTime}%';"))

# get_input = int(input("\n...请上传分省文件...倒计时20秒开始\n"))
# if get_input == 1:
#     print("\n----开始执行计划任务----")
#     from 和包项目.testcase.testUI.job_plan_tasks import run_task
#     # ----分省任务流
#     test_gitlab = run_task("admin", "123456")
#     test_gitlab.login_job()
#     test_gitlab.Search_options("credit定时任务", "全部", "全部", "分省业务办理确认文件解析处理任务", "sure_click")
#     test_gitlab.run_fenshen()
#     # ----待处理任务流
#     test_gitlab.Search_options("credit定时任务", "全部", "全部", "待处理列表", "sure_click")
#     test_gitlab.run_Wait_job()
#     test_gitlab.quit_windows()
# else:
#     print("\n----计划任务等待超时，已退出----")
















# bug-新增operator_id
# from hb_config import Deve_envirment as de
# from 和包项目.mysql.hebao_mysql import hb_mysql
# test4 = str(hb_mysql().delete_info("dev_credit", "credit_loan_apply", f"UPDATE `dev_credit`.`credit_loan_apply` SET `operator_id` = '000GUS0000000002' where `thirdpart_apply_id` = '{de.loan_conf['brwOrdNo']}';"))
