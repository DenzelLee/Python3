import seldom
from time import sleep
from page.jincheng_page import Login_jincheng
# from Python3.Seldom.mytest_pro.page.yunrong_page import Personal_center
import time
from selenium.webdriver.support.ui import Select
from selenium import webdriver
from time import sleep

class Jincheng(seldom.TestCase):
    ROBOT_LIBRARY_SCOPE = 'GLOBAL'
    # def test_login_yunrong(self):
    #     """登陆账户"""
    #     login = Login_jincheng(self.driver)
    #     login.get("https://cms-dev.corp.jccfc.com/jclogin/login.html")
    #     login.login_name = "hundsun"
    #     login.login_password = "111111"
    #     login.login_button.click()
    #     sleep(1.5)
    #     self.assertTitle("科技让金融更普惠")
    def test_login_job(self, username="hundsun", password="111111"):
        self.username = username
        self.password = password
        print("\n----开始登录计划信贷系统----")
        # 登陆
        self.driver = webdriver.Chrome()
        self.driver.get("https://cms-dev.corp.jccfc.com/jclogin/login.html")
        self.driver.implicitly_wait(10)
        self.driver.maximize_window()
        self.driver.find_element_by_css_selector('.input-outer>[name="login-name"]').clear()
        self.driver.find_element_by_css_selector('.input-outer>[name="login-name"]').send_keys(self.username)
        self.driver.find_element_by_css_selector('.input-outer>[name="login-pass"]').clear()
        self.driver.find_element_by_css_selector('.input-outer>[name="login-pass"]').send_keys(self.password)
        self.driver.find_element_by_css_selector('.act-but.submit').click()
        sleep(1.5)
        self.assertTitle("科技让金融更普惠")
        print("\n--成功登录计划信贷系统----")




