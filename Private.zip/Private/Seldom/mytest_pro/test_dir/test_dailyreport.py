import seldom
from time import sleep
from page.yunrong_page import Login_yunrong
from page.yunrong_page import Personal_center
# from Python3.Seldom.mytest_pro.page.yunrong_page import Personal_center

class Yunrong(seldom.TestCase):
    def test_login_yunrong(self):
        """登陆账户"""
        login = Login_yunrong(self.driver)
        login.get("https://oa.yunrong.cn/seeyon/main.do")
        login.login_name = "li hao"
        login.login_password = "123456leo"
        login.login_button.click()
        sleep(1.5)
        self.assertTitle("云融金科 V6.1SP2, 李浩,您好!")
    def test_open_daily_windows(self):
        """打开日报"""
        write = Personal_center(self.driver)
        write.switch_to_frame("#main")
        write.daily_link.click()
        sleep(1.5)
        write.new_window_handle()
        write.get_title()
        self.assertTitle("云融金科 V6.1SP2, 李浩,您好!")



