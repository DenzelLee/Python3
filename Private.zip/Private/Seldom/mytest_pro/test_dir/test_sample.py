import seldom
from page.sample_page import BaiduPage


class YouTest(seldom.TestCase):

    def test_case(self):
        """a simple test case """
        page = BaiduPage(self.driver)
        page.get("https://www.baidu.com")
        page.search_input = "seldom"
        page.search_button.click()
        self.assertTitle("seldom")

