import seldom


if __name__ == '__main__':
    # run test
    # seldom.main("./test_dir/")
    # seldom.main("./test_dir/test_sample.py")
    # seldom.main("./test_dir/test_dailyreport.py")
    # seldom.main("./test_dir/test_hb_dev_upgrade.py")
    seldom.main("test_dir/test_baidu.py")

