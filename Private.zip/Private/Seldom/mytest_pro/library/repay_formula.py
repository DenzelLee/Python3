#!/usr/bin/env/python3
# -*- coding:utf-8 -*-
'''
Author:leo
Date&Time:2019/11/29 and 11:15
Project:Python3
FileName:Repay_formula
Description：...
还款方式：
1.提前还款
2.正常还款: 本金*年利率/12*月份=四舍五入（保留2位，第三位四舍五入）
3.逾期还款:
'''
class Repay_formula():
    def service_charge(self, total_principal, total_month, total_rate=0.23):
        ''' 单期还款手续费=借款本金*总费率/总期数
        1）（非最后一期）单期还款金额=借款本金/总期数+借款本金*总费率/总期数
        2）（最后一期）还款金额=【借款本金-单期还款本金*（总期数-1）】+【借款本金*总费率- 单期还款手续费*（总期数-1）】
        3）  金额保留2位小数，利率保留6位小数，四舍五入'''
        # 月还款
        month_principal = total_principal/total_month    # 月还款本金
        month_service_charge_money = total_principal * total_rate / total_month  # 月还款手续费
        totol_month_charge_money = month_principal + month_service_charge_money  # 月还款总额
        service_charge_money = round(total_principal * total_rate * 100, 2) / 100.0  # 总还款手续费

        # 末月还款
        last_month_principal = total_principal - round(month_principal*100.0)/100.0 * (total_month - 1.0)  # 最后一期还款本金/手续费/总额
        last_month_service_charge_money = total_principal * total_rate-(round(month_service_charge_money*100.0)/100.0 * (total_month - 1.0))
        last_month_charge_money = last_month_principal + last_month_service_charge_money

        # 商户费用(放款本金*0.04)(放款本金*0.02/24+实际分期手续费*0.05)
        first_repay = total_principal * 0.04  # 首次还款服务费（商户）
        normal_repayment = (round(total_principal*100.0)/100.0 * 0.02/24)+(round(month_service_charge_money*100.0)/100.0 * 0.05)  # 正常还款服务费（商户）
        early_repayment = (round(total_principal*100.0)/100.0 * 0.02/24)+(round(month_service_charge_money*100.0)/100.0 * 0.05)  # 提前还款服务费（商户）

        print("\n----还款统计----")
        print("\n总应还本费:", str(total_principal + service_charge_money), "总应还本金:", str(total_principal), "总中移分期手续费:", str(service_charge_money))
        print("\n月应还总额:", str(totol_month_charge_money), "月应还本金:", str(month_principal), "月应还中移分期手续费:", str(month_service_charge_money))
        print("\n末月应还总额:", str(last_month_charge_money), "末月应还本金:", str(last_month_principal), "末应还中移分期手续费:", str(last_month_service_charge_money))
        print("\n首次还款服务费:", str(first_repay), "正常还款服务费:", str(normal_repayment), "提前还款服务费:", str(early_repayment))

        return total_principal + service_charge_money

    def early_repay(self, Residual_principal):
        ''' 提前还款违约金 = 剩余本金*3% '''
        early_repay_money = Residual_principal * 0.03
        print("\n提前还款违约金:", str(early_repay_money))
        return early_repay_money

    def overdue_repay(self, overdue_principal,overdue_days):
        ''' 逾期违约金=逾期本金*0.1%*逾期天数(单日罚息四舍五入后再累加，得到总罚息） '''
        overdue_repay_money = round(overdue_principal * 0.001*100.0)/100.0 * overdue_days
        print("\n逾期违约金:", str(overdue_repay_money))
        return overdue_repay_money

if __name__ == "__main__":
    test = Repay_formula()
    m1 = test.service_charge(1000.99, 24.0)
    m2 = test.early_repay(917.57)
    m3 = test.overdue_repay(41.71, 0)  # 当期应还本金
    print("总额（本金+手续费+违约金）：", m1+m2+m3)