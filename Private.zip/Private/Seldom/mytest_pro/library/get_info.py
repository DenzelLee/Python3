#!/usr/bin/env/python3
# -*- coding:utf-8 -*-
'''
Author:leo
Date&Time:2019/11/22 and 15:51
Project:Python3
FileName:get_info
Description：...
'''
# 读取文件内容并赋值
class Get_information():
    def read_txt(self, info_filename, line_num=1):
        """
        :param info_filename: 已存在的四要素文件名（txt类型）
        :param line_num: 读取需要的数据行数（文本真实行数，代码已经-1）
        :return: 返回选定行的格式化数据
        """
        print("\n----用戶数据----\n")
        filepath1 = "D:\Mytest\Python3\Python3\云融项目\和包项目\\testfile\\"
        with open(filepath1 + info_filename, "r", encoding="utf-8") as txtfile:
            # readone = rfile.readline()   # 单行字符串
            # print(type(readone), readone)
            # rfile.seek(0, 0)
            readmore = txtfile.readlines()  # 列表
            get_one_info = readmore[int(int(line_num) - 1)].replace("\n", "").replace("\ufeff", "").replace(" ", "").replace("\t", ",").split(',')
            # print(info_name, info_carid, info_bankid, info_phone)
            return get_one_info

    def read_csv(self, info_filename, info_type="info_total", data_num=1):
        """
        :param info_filename: 已存在的四要素文件名（csv类型）
        :param info_type: 读取的数据类型（全部，单行，单列）
        :param line_num: 读取的数据行数（文本真实行数，代码已经-1）
        :return:全部，单行，单列
        """
        import csv
        filepath = "/云融项目/和包项目/testfile/practice\\"
        with open(filepath + info_filename, 'r', encoding="gbk") as csvFile:
            total_data_list = []
            if info_type == "info_total":
                read_class = csv.reader(csvFile)
                print("\n----全部数据:"+str(read_class)+"<return:list>")
                for data in read_class:
                    # print(data)
                    total_data_list.append(data)
                return total_data_list
            elif info_type == "info_row":  # 行:获取行，必须转换为列表，通过索引读取数据
                read_class = csv.reader(csvFile)
                read_line_list = list(read_class)
                row = read_line_list[int(data_num)-1]
                print(f"\n----单行数据:{type(row)}")
                # print(row)
                return row
            elif info_type == "info_column":  # 列：获取列，直接原始类型通过下标[num]读取数据
                read_class = csv.reader(csvFile)
                print("\n----单列数据:<class 'str'>")
                for column in read_class:
                    print(column[int(data_num)-1])
                return column[int(data_num)-1]
            else:
                print("Info_type类型错误:请输入正确参数值")
                return None
        return
if __name__ == "__main__":
    # 获取txt用户信息四要素
    get_one_info = Get_information().read_txt("user_info1000.txt","1")
    info_name, info_carid, info_bankid, info_phone = get_one_info[0], get_one_info[1], get_one_info[2], get_one_info[3]
    print(info_name, info_carid, info_bankid, info_phone)

    # # 获取csv用户信息四要素
    # get_one_info_csv = Get_information().read_csv("csv_test.csv", "info_total")
    # print(get_one_info_csv)  # 全部数据
    # get_one_info_csv = Get_information().read_csv("csv_test.csv", "info_row", 1)
    # print(get_one_info_csv)  # 单行数据
    # get_one_info_csv = Get_information().read_csv("csv_test.csv", "info_column", 1)
    # print(get_one_info_csv)  # 单列数据
    # Get_information.read_txt("test001.csv",)

