#!/usr/bin/env/python3
# -*- coding:utf-8 -*-
'''
Author:leo
Date&Time:2019/11/19 and 10:30
Project:Python3
FileName:credit
Description：
公共模块：
1.登陆账户
2.加密/解密
3.执行api单接口测试
'''
import datetime, time, random,linecache
from pprint import pprint
import requests
import json
# 导入自定义配置文件
import sys
sys.path.append(r'D:\Mytest\Python3\Python3\Seldom\mytest_pro')
from page.hb_config import Deve_envirment as de

# 获取当前格式化-年月日：时分秒
logTime = time.strftime('%Y%m%d_%H:%M:%S', time.localtime(time.time()))
nowTime = time.strftime('%Y%m%d %H%M%S', time.localtime(time.time()))
# 生成年月日(8)/时分秒(6)/随机整数(5)
date = nowTime.split(" ")[0]
time = nowTime.split(" ")[1]
number = str(random.randint(100, 999))

class Basic():
    # # 登录账户
    # def interlogin(self):
    #     print("----开始登陆----")
    #     if not isinstance(x, (int, float)):  #  类型检查举例（如果不是int和float，就报类型错误）
    #         raise TypeError('bad operand type')
    #     loginurl = f"http://{insideDatabase[0]}:{insideDatabase[1]}/api/mgr/loginReq"
    #     response = requests.post(url=loginurl, data={"username": "auto", "password": "sdfsdfsdf"})
    #     res = response.json()
    #     self.cookies = dict(response.cookies)
    #     print(self.cookies)
    #     print(f"----登陆成功：{res}----")c
    #     return res
    # 加密
    def jiami(self, jiami_headers, jiami_payload):
        print("\n开始加密")
        url = f"{de.jiami_http['url']}"
        headers = jiami_headers
        payload = jiami_payload
        response = requests.post(url=url, headers=headers, json=payload)
        res = response.json()
        res = str(res).replace("'",'''"''').replace(" ", "")
        print(f"加密成功，响应报文如下：\n{res}")
        return res
    # 解密
    def jiemi(self, jiemi_headers, jiemi_payload):
        print("\n开始解密")
        url = f"{de.jiemi_http['url']}"
        headers = jiemi_headers
        payload = jiemi_payload
        response = requests.post(url=url, headers=headers, data=payload)
        res = response.json()
        res = str(res).replace("'",'''"''').replace(" ", "")
        print(f"----解密成功，响应报文如下：----\n{res}")
        return res
    # 执行接口
    def runapi(self, url, headers, payload):
        # proxies = {"http": "router-dev.jccfc.com:443", "https": "router-dev.jccfc.com:443"}
        response = requests.post(url=url, headers=headers, data=payload)
        # requests.post(url, )
        res = response.json()
        res = str(res).replace("'", '''"''').replace(" ", "")
        return res
    # 接口测试请求体变量写入txt文件(log日志）
    def write_txt(self,filename,functionname,log_info):
        filepath = "/云融项目/和包项目/testfile\\"
        # 写入新文件（如果没有文件后缀.txt，默认文本文件）
        with open(filepath + f'{filename}.txt', mode="a+", encoding="utf8") as wfile:
            wfile.write("\n(name：)"+functionname+"\n(date：)"+logTime+"\n(data：)"+log_info+"\n")
            wfile.write("\n")
            wfile.seek(0, 0)
            new = wfile.read()
            # print(str(new))
    # 读取文件内容并赋值
    def read_info(self,info_filename,line_num=1):
        filepath1 = "D:\Mytest\Python3\Python3\云融项目\和包项目\\testfile\\"
        with open(filepath1 + info_filename, "r", encoding="utf-8") as rfile:
            # readone = rfile.readline()   # 单行字符串
            # print(type(readone), readone)
            # rfile.seek(0, 0)
            readmore = rfile.readlines()  # 列表
            get_one_info = readmore[int(int(line_num)-1)].replace("\n","").replace("\t", ",").split(',')
            # print(type(get_one_info), get_one_info)
            # rfile.seek(0, 0)
            # readall = rfile.read()        # 全文字符串
            # print(type(readall),"\n"+readall)
            # rfile.seek(0, 0)
            return get_one_info
    def read_someone(self,num):
        readsomeon = linecache.getline(r"D:\Mytest\Python3\Python3\云融项目\和包项目\testfile\user_info.txt", num)
        print(readsomeon)
        return
    def progress_bar_wait_time(self, time_secend):
        from tqdm import tqdm
        import time
        pbar = tqdm([wait_second for wait_second in range(int(time_secend)+1)][1:])  # 首先使用tqdm定义了一个迭代器
        for char in pbar:
            time.sleep(1)
            # 设置进度显示的名称使用的是set_description(设置描述):进程的名字.
            pbar.set_description("----等待时间 {:<2}".format(char))  # 不能加\n换行，否则会多行进度条

    def wait_time_difference(self, delay_time):
        import time
        def wait_timer(func):
            def wrapper(*args, **kwds):
                t0_time = time.time()
                func(*args, **kwds)
                t1_time = time.time()
                print('一共耗时：%0.2f' % (t1_time - t0_time,))
            return wrapper
        # 装饰器时间差:@加函数名约等于执行wait_timer（do_something(delay_time)），把下一个整个函数作为上一个函数参数传递，并执行。
        @wait_timer
        def do_something(delay_time):
            # print('函数do_something开始')
            time.sleep(delay_time)
            # print('函数do_something结束')
        do_something(delay_time)

if __name__ == "__main__":
    # pass
    # Basic().progress_bar_wait_time(15)
    # test = Basic()
    # get_tmp_info = test.read_info("user_info1.txt", 1)
    # info_name,info_carid,info_bankid,info_phone = get_tmp_info[0],get_tmp_info[1],get_tmp_info[2],get_tmp_info[3]
    # print(info_name,info_carid,info_bankid,info_phone)

    Basic().wait_time_difference(3)