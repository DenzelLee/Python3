#!/usr/bin/env/python3
# -*- coding:utf-8 -*-
'''
Author:leo
Date&Time:2020/2/5 and 16:34
Project:Python3
FileName:20200205_tmp
Description：...
'''

class Tmp():
    def open_exists_reports(self):
        from selenium import webdriver
        import time, os
        ''' 获取报告目录的文件名，通过浏览器打开文件报告 '''
        for root, dirs, files in os.walk(f'{os.getcwd()}\\reports'):
            for file in files:
                # 判断后缀为html的
                # if os.path.splitext(file)[1] == '.html':
                last_filename = f"{os.getcwd()}\\reports\\{files[-1]}"
                # print(type(last_filename), last_filename)
            driver = webdriver.Chrome()
            driver.get(last_filename)
            time.sleep(15)
            driver.quit()
if __name__ == '__main__':
    Tmp().open_exists_reports()