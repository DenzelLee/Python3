#!/usr/bin/env/python3
# -*- coding:utf-8 -*-
import seldom
from seldom import data, data_class
#
# @data_class(
#     ("ckeyword", "cassert_tile"),  # 用于后面类实例化test_class_baidu
#     [("seldom2", "seldom2_百度搜索"),
#      ("python2", "python2_百度搜索")
#      ])

class YouTest(seldom.TestCase):

   # 普通百度搜索
    def test_nomal_baidu(self):
        """默认简单案例 """
        self.open("https://www.baidu.com")
        self.type(id_="kw", text="seldom0")
        self.click(css="#su")
        self.assertInTitle("seldom0")

    # 变量参数化
    @data([
        (1, 'seldom1'),
        (2, 'selenium1'),
        (3, 'unittest1'),
    ])
    def test_variale_baidu(self, name, keyword):
        """
         参数化变测试用例
        :param name: case name
        :param keyword: search keyword
        """
        self.open("https://www.baidu.com")
        self.type(id_="kw", text=keyword)
        self.click(css="#su")
        self.assertTitle(keyword + "_百度搜索")

    # # 类参数化
    # def test_class_baidu(self):
    #     """参数化变测试类 """
    #     self.open("https://www.baidu.com")
    #     self.type(id_="kw", text=self.ckeyword)
    #     self.click(css="#su")
    #     self.assertTitle(self.cassert_tile)

if __name__ == '__main__':
    seldom.main("test_sample.py")


