#!/usr/bin/env/python3
# -*- coding:utf-8 -*-
import seldom

if __name__ == '__main__':
    # run test
    # seldom.main("./test_dir/")
    # seldom.main("./test_dir/test_sample.py")
    seldom.main("./test_dir/test_sample.py",
                browser="chrome",
                title="百度测试用例",
                description="测试环境：windows 10/ chrome",
                rerun=0,  # 错误重跑次数，默认0
                save_last_run=False,  # 重跑是否只保存最后一次运行结果，默认为False，每次都保存。
                open_report=True  # 自动打开报告
                )



